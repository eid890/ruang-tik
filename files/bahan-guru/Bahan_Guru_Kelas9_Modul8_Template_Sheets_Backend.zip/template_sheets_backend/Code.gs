/**
 * TEMPLATE BACKEND GOOGLE SHEETS - Kelas IX Modul 8
 * PP Wihdatul Ummah Poso
 *
 * Cara pakai:
 * 1. Buat Google Sheets. Ganti nama lembar menjadi: Setoran
 * 2. Baris 1 (judul kolom): Waktu | Kode | Surat | Ayat
 * 3. Extensions > Apps Script. Hapus isi Code.gs, tempel seluruh kode ini.
 * 4. Save, lalu Deploy > New deployment > Web app
 *    Execute as: Me   |   Who has access: Anyone
 * 5. Salin Web app URL ke index.html (URL_APPS_SCRIPT).
 *
 * PENTING: hanya untuk DATA LATIHAN (fiktif). Jangan menyimpan nama lengkap,
 * alamat, nomor HP, atau data pribadi lainnya.
 */

const NAMA_SHEET = 'Setoran';

// Membaca semua data (dipanggil saat website memuat daftar)
function doGet(e) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(NAMA_SHEET);
  const data = sheet.getDataRange().getValues();
  const judul = data.shift();                 // baris pertama = judul kolom
  const hasil = data.map(function (baris) {
    const obj = {};
    judul.forEach(function (j, i) { obj[j] = baris[i]; });
    return obj;
  });
  return ContentService
    .createTextOutput(JSON.stringify(hasil))
    .setMimeType(ContentService.MimeType.JSON);
}

// Menyimpan satu baris data baru (dipanggil saat formulir dikirim)
function doPost(e) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(NAMA_SHEET);
  const p = e.parameter;
  const kode = String(p.kode || '').trim().slice(0, 10);
  const surat = String(p.surat || '').trim().slice(0, 40);
  const ayat = Number(p.ayat);

  // Validasi sederhana: tolak data yang tidak wajar
  if (kode === '' || isNaN(ayat) || ayat < 0 || ayat > 300) {
    return ContentService.createTextOutput('ditolak');
  }

  sheet.appendRow([new Date(), kode, surat, ayat]);
  return ContentService.createTextOutput('ok');
}
